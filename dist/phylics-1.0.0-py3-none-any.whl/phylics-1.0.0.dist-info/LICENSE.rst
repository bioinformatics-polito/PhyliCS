PhyliCS copyright
================
::

  Copyright (c) 2018-2020, Marilisa Montemurro, Elena Grassi, and Gianvito Urgese.

PhyliCS is *free software*: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

PhyliCS is distributed in the hope that it will be useful,
but **without any warranty**; without even the implied warranty of
**merchantability** or **fitness for a particular purpose**.

See the file `LICENSE-AGPL3.rst <./LICENSE-AGPL3.rst>`__ or
http://www.gnu.org/licenses/ for a full text of the license and the
rights and obligations implied.

We obtained and adapted to our needs Gingko code, which is licensed under "BSD 2-Clause "Simplified" License", we kept its license notice as needed. It can be found in the file `phylics/local/src/ginkgo//LICENSE <./phylics/local/src/ginkgo/LICENSE>`__.
